# project mode — summary (72h)

- Generated: 2026-11-26T18:04:36.210Z
- Commit: 6c706f5
- Release: 131.9
- Log rows (mode-filtered): 0
- Total application log rows in window: 972

See shared/REQUEST_INDEX.md for user↔reply index and shared/conversations-full.md for the full diagnostic narrative.
