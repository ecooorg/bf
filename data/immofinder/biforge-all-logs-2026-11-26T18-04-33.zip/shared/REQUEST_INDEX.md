# Request index (recent conversation exchanges)

Built from `simple_direct_exchange` and `conversation_response_pipeline` events.
Each block links requestId → user text → search → model → reply preview.

_No exchange events in window. Deploy P126.19+ and run a Simple/Expert turn to populate._
