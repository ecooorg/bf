# Assistant brief — BiForge All Logs

## Snapshot
```json
{
  "generatedAt": "2026-11-26T18:04:36.211Z",
  "windowHours": 72,
  "commit": "6c706f5",
  "release": "131.9",
  "totals": {
    "applicationLogRows": 972,
    "consoleLines": 120,
    "simpleRows": 0,
    "expertRows": 0,
    "projectRows": 0,
    "exchangeEvents": 0,
    "clientRenderAcks": 0
  },
  "qualitySignals": {
    "errorRows": 3,
    "warnRows": 13,
    "httpFailures": 0
  },
  "notes": [
    "Only API keys and Bearer [REDACTED] are redacted.",
    "P126.19: REQUEST_INDEX links requestId to user text and reply; client-render acks mark painted replies.",
    "Mode folders use productMode/agent tags; shared/conversations-full.md is the single full narrative."
  ]
}
```

## How to read
- `shared/REQUEST_INDEX.md` — start here for user-visible turns
- `simple|expert|project/exchanges.jsonl` — mode-scoped exchange events
- `shared/conversations-full.md` — full diagnostic narrative (once)
