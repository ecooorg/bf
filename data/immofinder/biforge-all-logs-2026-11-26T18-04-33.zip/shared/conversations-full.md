BIFORGE CONVERSATION DIAGNOSTIC LOG (Simple and Expert)
exportedAt=2026-11-26T18:04:36.118Z
appVersion=131 patch=131.9 runtimeCommit=6c706f5
buildStamp=MATCH stampCommit=6c706f5 builtAt=2026-11-26T17:41:52.548Z stampPatch=131.9
releaseMatchesRepoPackagePatch=yes
applicationLogSource=database+memory databaseLogWriteFailures=0
PROCESS:
pid=85 uptimeSec=1322 rssMb=226 heapUsedMb=111 memoryLimitMb=512 node=v22.12.0
BOOT_HISTORY (last 20 process_boot records; previousShutdown explains why the earlier process stopped):
Thu Nov 26 2026 16:50:05 GMT+0000 (Coordinated Universal Time) INFO process_boot request=- message=BiForge server process initialized details={"node":"v22.12.0","rssMb":143,"bootId":"245068f0-c71e-4215-b9a6-6faa803055e5","commit":"d8aa670","nodeEnv":"production","uptimeSec":11,"appVersion":"131","heapUsedMb":55,"hasGeminiKey":true,"memoryLimitMb":512,"hasDatabaseUrl":true,"appBuilderEngine":"staged","previousShutdown":"no_record (first start, or the filesystem was reset by a new container or deploy)","projectModeEnabled":true,"previousShutdownDetail":{"found":false,"reason":"no_record (first start, or the filesystem was reset by a new container or deploy)"}}
Thu Nov 26 2026 16:55:11 GMT+0000 (Coordinated Universal Time) INFO process_boot request=- message=BiForge server process initialized details={"node":"v22.12.0","rssMb":141,"bootId":"08dcdb3f-a2f7-4faf-b478-9c714d99d572","commit":"00c2831","nodeEnv":"production","uptimeSec":10,"appVersion":"131","heapUsedMb":55,"hasGeminiKey":true,"memoryLimitMb":512,"hasDatabaseUrl":true,"appBuilderEngine":"staged","previousShutdown":"no_record (first start, or the filesystem was reset by a new container or deploy)","projectModeEnabled":true,"previousShutdownDetail":{"found":false,"reason":"no_record (first start, or the filesystem was reset by a new container or deploy)"}}
Thu Nov 26 2026 16:59:13 GMT+0000 (Coordinated Universal Time) INFO process_boot request=- message=BiForge server process initialized details={"node":"v22.12.0","rssMb":146,"bootId":"1ec5403c-bd00-4893-baa5-bb1b72064f30","commit":"bcfb7f9","nodeEnv":"production","uptimeSec":10,"appVersion":"131","heapUsedMb":56,"hasGeminiKey":true,"memoryLimitMb":512,"hasDatabaseUrl":true,"appBuilderEngine":"staged","previousShutdown":"no_record (first start, or the filesystem was reset by a new container or deploy)","projectModeEnabled":true,"previousShutdownDetail":{"found":false,"reason":"no_record (first start, or the filesystem was reset by a new container or deploy)"}}
Thu Nov 26 2026 17:02:45 GMT+0000 (Coordinated Universal Time) INFO process_boot request=- message=BiForge server process initialized details={"node":"v22.12.0","rssMb":146,"bootId":"a5186da5-9821-4bd2-a705-b44e8c159d11","commit":"e0f943e","nodeEnv":"production","uptimeSec":11,"appVersion":"131","heapUsedMb":56,"hasGeminiKey":true,"memoryLimitMb":512,"hasDatabaseUrl":true,"appBuilderEngine":"staged","previousShutdown":"no_record (first start, or the filesystem was reset by a new container or deploy)","projectModeEnabled":true,"previousShutdownDetail":{"found":false,"reason":"no_record (first start, or the filesystem was reset by a new container or deploy)"}}
Thu Nov 26 2026 17:04:03 GMT+0000 (Coordinated Universal Time) INFO process_boot request=- message=BiForge server process initialized details={"node":"v22.12.0","rssMb":153,"bootId":"3771786e-93e6-4d14-8de2-7be421ff3ee2","commit":"aca5e94","nodeEnv":"production","uptimeSec":11,"appVersion":"131","heapUsedMb":54,"hasGeminiKey":true,"memoryLimitMb":512,"hasDatabaseUrl":true,"appBuilderEngine":"staged","previousShutdown":"no_record (first start, or the filesystem was reset by a new container or deploy)","projectModeEnabled":true,"previousShutdownDetail":{"found":false,"reason":"no_record (first start, or the filesystem was reset by a new container or deploy)"}}
Thu Nov 26 2026 17:07:28 GMT+0000 (Coordinated Universal Time) INFO process_boot request=- message=BiForge server process initialized details={"node":"v22.12.0","rssMb":147,"bootId":"e374ed03-9e61-4c3c-b944-139bb27c8fd4","commit":"6afd6a0","nodeEnv":"production","uptimeSec":10,"appVersion":"131","heapUsedMb":55,"hasGeminiKey":true,"memoryLimitMb":512,"hasDatabaseUrl":true,"appBuilderEngine":"staged","previousShutdown":"no_record (first start, or the filesystem was reset by a new container or deploy)","projectModeEnabled":true,"previousShutdownDetail":{"found":false,"reason":"no_record (first start, or the filesystem was reset by a new container or deploy)"}}
Thu Nov 26 2026 17:10:00 GMT+0000 (Coordinated Universal Time) INFO process_boot request=- message=BiForge server process initialized details={"node":"v22.12.0","rssMb":143,"bootId":"751d69fe-d5ed-4976-a57f-39dfb91213df","commit":"316b476","nodeEnv":"production","uptimeSec":10,"appVersion":"131","heapUsedMb":56,"hasGeminiKey":true,"memoryLimitMb":512,"hasDatabaseUrl":true,"appBuilderEngine":"staged","previousShutdown":"no_record (first start, or the filesystem was reset by a new container or deploy)","projectModeEnabled":true,"previousShutdownDetail":{"found":false,"reason":"no_record (first start, or the filesystem was reset by a new container or deploy)"}}
Thu Nov 26 2026 17:12:45 GMT+0000 (Coordinated Universal Time) INFO process_boot request=- message=BiForge server process initialized details={"node":"v22.12.0","rssMb":140,"bootId":"8af4ec95-e1c8-4167-874e-63870ca7216a","commit":"4bb7de3","nodeEnv":"production","uptimeSec":10,"appVersion":"131","heapUsedMb":56,"hasGeminiKey":true,"memoryLimitMb":512,"hasDatabaseUrl":true,"appBuilderEngine":"staged","previousShutdown":"no_record (first start, or the filesystem was reset by a new container or deploy)","projectModeEnabled":true,"previousShutdownDetail":{"found":false,"reason":"no_record (first start, or the filesystem was reset by a new container or deploy)"}}
Thu Nov 26 2026 17:15:22 GMT+0000 (Coordinated Universal Time) INFO process_boot request=- message=BiForge server process initialized details={"node":"v22.12.0","rssMb":144,"bootId":"29340835-4196-4649-8b8c-659fe1a3a351","commit":"d5abb14","nodeEnv":"production","uptimeSec":11,"appVersion":"131","heapUsedMb":56,"hasGeminiKey":true,"memoryLimitMb":512,"hasDatabaseUrl":true,"appBuilderEngine":"staged","previousShutdown":"no_record (first start, or the filesystem was reset by a new container or deploy)","projectModeEnabled":true,"previousShutdownDetail":{"found":false,"reason":"no_record (first start, or the filesystem was reset by a new container or deploy)"}}
Thu Nov 26 2026 17:19:20 GMT+0000 (Coordinated Universal Time) INFO process_boot request=- message=BiForge server process initialized details={"node":"v22.12.0","rssMb":146,"bootId":"dd8548e2-f02f-451e-9f66-392e0715bbb7","commit":"29ffede","nodeEnv":"production","uptimeSec":11,"appVersion":"131","heapUsedMb":56,"hasGeminiKey":true,"memoryLimitMb":512,"hasDatabaseUrl":true,"appBuilderEngine":"staged","previousShutdown":"no_record (first start, or the filesystem was reset by a new container or deploy)","projectModeEnabled":true,"previousShutdownDetail":{"found":false,"reason":"no_record (first start, or the filesystem was reset by a new container or deploy)"}}
Thu Nov 26 2026 17:20:58 GMT+0000 (Coordinated Universal Time) INFO process_boot request=- message=BiForge server process initialized details={"node":"v22.12.0","rssMb":146,"bootId":"ae94a38a-debc-457a-a7cc-dedf53949413","commit":"962a00b","nodeEnv":"production","uptimeSec":11,"appVersion":"131","heapUsedMb":55,"hasGeminiKey":true,"memoryLimitMb":512,"hasDatabaseUrl":true,"appBuilderEngine":"staged","previousShutdown":"no_record (first start, or the filesystem was reset by a new container or deploy)","projectModeEnabled":true,"previousShutdownDetail":{"found":false,"reason":"no_record (first start, or the filesystem was reset by a new container or deploy)"}}
Thu Nov 26 2026 17:23:51 GMT+0000 (Coordinated Universal Time) INFO process_boot request=- message=BiForge server process initialized details={"node":"v22.12.0","rssMb":148,"bootId":"a654049c-4e7a-4d33-8534-3f0ad88e3fa7","commit":"3a25895","nodeEnv":"production","uptimeSec":11,"appVersion":"131","heapUsedMb":56,"hasGeminiKey":true,"memoryLimitMb":512,"hasDatabaseUrl":true,"appBuilderEngine":"staged","previousShutdown":"no_record (first start, or the filesystem was reset by a new container or deploy)","projectModeEnabled":true,"previousShutdownDetail":{"found":false,"reason":"no_record (first start, or the filesystem was reset by a new container or deploy)"}}
Thu Nov 26 2026 17:26:49 GMT+0000 (Coordinated Universal Time) INFO process_boot request=- message=BiForge server process initialized details={"node":"v22.12.0","rssMb":145,"bootId":"5c7c8704-08aa-45ac-a978-d1c9e83e8f25","commit":"6105aa9","nodeEnv":"production","uptimeSec":11,"appVersion":"131","heapUsedMb":56,"hasGeminiKey":true,"memoryLimitMb":512,"hasDatabaseUrl":true,"appBuilderEngine":"staged","previousShutdown":"no_record (first start, or the filesystem was reset by a new container or deploy)","projectModeEnabled":true,"previousShutdownDetail":{"found":false,"reason":"no_record (first start, or the filesystem was reset by a new container or deploy)"}}
Thu Nov 26 2026 17:28:09 GMT+0000 (Coordinated Universal Time) INFO process_boot request=- message=BiForge server process initialized details={"node":"v22.12.0","rssMb":147,"bootId":"a02fe614-ec33-41d6-9017-a1fa4f9671a6","commit":"d96d564","nodeEnv":"production","uptimeSec":11,"appVersion":"131","heapUsedMb":55,"hasGeminiKey":true,"memoryLimitMb":512,"hasDatabaseUrl":true,"appBuilderEngine":"staged","previousShutdown":"no_record (first start, or the filesystem was reset by a new container or deploy)","projectModeEnabled":true,"previousShutdownDetail":{"found":false,"reason":"no_record (first start, or the filesystem was reset by a new container or deploy)"}}
Thu Nov 26 2026 17:29:52 GMT+0000 (Coordinated Universal Time) INFO process_boot request=- message=BiForge server process initialized details={"node":"v22.12.0","rssMb":148,"bootId":"3090be22-2dc3-4284-b1d0-5bc06741ed68","commit":"da0c1e8","nodeEnv":"production","uptimeSec":11,"appVersion":"131","heapUsedMb":54,"hasGeminiKey":true,"memoryLimitMb":512,"hasDatabaseUrl":true,"appBuilderEngine":"staged","previousShutdown":"no_record (first start, or the filesystem was reset by a new container or deploy)","projectModeEnabled":true,"previousShutdownDetail":{"found":false,"reason":"no_record (first start, or the filesystem was reset by a new container or deploy)"}}
Thu Nov 26 2026 17:31:17 GMT+0000 (Coordinated Universal Time) INFO process_boot request=- message=BiForge server process initialized details={"node":"v22.12.0","rssMb":148,"bootId":"81e45842-dd74-419f-a111-f0594b7db44e","commit":"c5797f1","nodeEnv":"production","uptimeSec":10,"appVersion":"131","heapUsedMb":56,"hasGeminiKey":true,"memoryLimitMb":512,"hasDatabaseUrl":true,"appBuilderEngine":"staged","previousShutdown":"no_record (first start, or the filesystem was reset by a new container or deploy)","projectModeEnabled":true,"previousShutdownDetail":{"found":false,"reason":"no_record (first start, or the filesystem was reset by a new container or deploy)"}}
Thu Nov 26 2026 17:37:20 GMT+0000 (Coordinated Universal Time) INFO process_boot request=- message=BiForge server process initialized details={"node":"v22.12.0","rssMb":141,"bootId":"35693e49-8eda-4d6b-b383-ddd317c0c0aa","commit":"2897faf","nodeEnv":"production","uptimeSec":10,"appVersion":"131","heapUsedMb":56,"hasGeminiKey":true,"memoryLimitMb":512,"hasDatabaseUrl":true,"appBuilderEngine":"staged","previousShutdown":"no_record (first start, or the filesystem was reset by a new container or deploy)","projectModeEnabled":true,"previousShutdownDetail":{"found":false,"reason":"no_record (first start, or the filesystem was reset by a new container or deploy)"}}
Thu Nov 26 2026 17:38:39 GMT+0000 (Coordinated Universal Time) INFO process_boot request=- message=BiForge server process initialized details={"node":"v22.12.0","rssMb":153,"bootId":"8ece00d5-e9dc-4924-9c8c-41a5349ebd7d","commit":"79a1096","nodeEnv":"production","uptimeSec":10,"appVersion":"131","heapUsedMb":55,"hasGeminiKey":true,"memoryLimitMb":512,"hasDatabaseUrl":true,"appBuilderEngine":"staged","previousShutdown":"no_record (first start, or the filesystem was reset by a new container or deploy)","projectModeEnabled":true,"previousShutdownDetail":{"found":false,"reason":"no_record (first start, or the filesystem was reset by a new container or deploy)"}}
Thu Nov 26 2026 17:42:44 GMT+0000 (Coordinated Universal Time) INFO process_boot request=- message=BiForge server process initialized details={"node":"v22.12.0","rssMb":148,"bootId":"1a15ce9e-6206-4b44-81ba-d4a50ece1c58","commit":"6c706f5","nodeEnv":"production","uptimeSec":10,"appVersion":"131","heapUsedMb":56,"hasGeminiKey":true,"memoryLimitMb":512,"hasDatabaseUrl":true,"appBuilderEngine":"staged","previousShutdown":"no_record (first start, or the filesystem was reset by a new container or deploy)","projectModeEnabled":true,"previousShutdownDetail":{"found":false,"reason":"no_record (first start, or the filesystem was reset by a new container or deploy)"}}
2026-11-26T17:42:43.617Z INFO process_boot request=- message=BiForge server process initialized details={"previousShutdown":"no_record (first start, or the filesystem was reset by a new container or deploy)","previousShutdownDetail":{"found":false,"reason":"no_record (first start, or the filesystem was reset by a new container or deploy)"},"bootId":"1a15ce9e-6206-4b44-81ba-d4a50ece1c58","uptimeSec":10,"rssMb":148,"heapUsedMb":56,"memoryLimitMb":512,"commit":"6c706f5","node":"v22.12.0","nodeEnv":"production","appVersion":"131","projectModeEnabled":true,"appBuilderEngine":"staged","hasDatabaseUrl":true,"hasGeminiKey":true}
CONFIG_SNAPSHOT (non-secret values in full; secrets only as set/length/short SHA-256 fingerprint):
APP_BUILDER_ENGINE=staged
APP_BUILDER_MODEL_SLICE=true
APP_PASSWORD: SECRET set=true length=10 sha256=18ccef2d
BIFORGE_GEMINI_DIRECT_MODE=true
BLACK=[30m
BLUE=[34m
BOLD=[1m
BUN_HOME=/home/render/.bun
BUN_VERSIONS_DIR=/opt/render/project/bun
CODE_APP_BUILDER_MAX_FILES=80
CODE_APP_BUILDER_MAX_LINES=8000
CODE_EXECUTOR=model_patch
COLOR=0
CYAN=[36m
DAILY_CALL_CAP=1000
DATABASE_URL: SECRET set=true length=93 sha256=407e8126
DEBIAN_FRONTEND=noninteractive
DEFAULT_BUN_VERSION=1.4.5
DEFAULT_NODE_VERSION=24.22.1
DEFAULT_POETRY_VERSION=2.1.3
DEFAULT_PYTHON_VERSION=3.14.10
DEFAULT_UV_VERSION=0.13.7
DIM=[2m
ENABLE_APP_AUTH: SECRET set=true length=4 sha256=b5bea41b
ENABLE_EXTERNAL_MODEL_FALLBACK=true
ENABLE_GEMINI_CANDIDATE_PROBES=false
ENABLE_PROJECT_MODE=true
ENABLE_WEB_SEARCH=true
ENTER_STANDOUT=[7m
EXIT_STANDOUT=[27m
GATSBY_TELEMETRY_DISABLED=1
GEMINI_API_KEY=[REDACTED_API_KEY] set=true length=53 sha256=edb6ff5c
GEMINI_API_KEY_1: SECRET set=true length=53 sha256=f865fd04
GEMINI_API_KEY_2: SECRET set=true length=53 sha256=fe29a296
GEMINI_API_KEY_3: SECRET set=true length=53 sha256=3a436aed
GEMINI_API_KEY_4: SECRET set=true length=53 sha256=4f2f23cc
GEMINI_API_KEY_5: SECRET set=true length=53 sha256=3ac91c4c
GEMINI_API_KEY_6: SECRET set=true length=53 sha256=a9cecf13
GEMINI_API_KEY_7: SECRET set=true length=53 sha256=7e6dcb20
GEMINI_API_KEY_8: SECRET set=true length=53 sha256=397b78c6
GEMINI_API_KEY_9: SECRET set=true length=53 sha256=bda670f3
GITHUB_APP_ID=5276629
GITHUB_APP_INSTALLATION_ID=170347326
GITHUB_APP_PRIVATE_KEY: SECRET set=true length=1674 sha256=4b272d89
GITHUB_DIFF_UPLOAD=true
GITHUB_REPOSITORY_NAME=bf
GITHUB_REPOSITORY_OWNER=ecooorg
GITHUB_WEBHOOK_SECRET: SECRET set=true length=40 sha256=553e19bf
GOOGLE_SERVICE_ACCOUNT_JSON={
  "type": "service_account",
  "project_id": "project-4caea996-9c73-4ae7-bc8",
  "private_key_id": "69d0360bbfa0987cb36af8733a455347b6a2857a",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQDV8Ebdn/6yGixQ\nPwGlJOdF2EPAQsC+YxybSadYb5nRyn0tPMknMxU7Nu
GREEN=[32m
GROQ_API_KEY=[REDACTED_API_KEY] set=true length=56 sha256=90619d2c
GROQ_PLAN=free
GROUNDED_NUMBER_CHECK=true
IMMOFINDER_BASE_URL=https://bf-3tqo.onrender.com
IMMOFINDER_BOOT_RUN_AFTER=2026-11-26T16:17:00Z
IMMOFINDER_DRIVE_FOLDER_ID=199CkTuXRf52H0r-8-KTOsI-nFQFnZoxT
IMMOFINDER_DRIVE_SHARE_EMAIL=ecooorg@gmail.com
IMMOFINDER_GITHUB_BRANCH=main
IMMOFINDER_GITHUB_REPOSITORY=ecooorg/bf
IMMOFINDER_GITHUB_TOKEN: SECRET set=true length=93 sha256=b40f51ce
IMMOFINDER_RUN_SECRET: SECRET set=true length=32 sha256=3b2a1f1c
IS_PULL_REQUEST=false
JINA_API_KEY=[REDACTED_API_KEY] set=true length=65 sha256=0cd3b425
JINA_READER_BASE_URL=https://r.jina.ai
KEEP_ALIVE=false
LLM_CALL_TIMEOUT_MS=12000
LLM_TOTAL_DEADLINE_MS=30000
MAGENTA=[35m
MAX_BODY_BYTES=262144
MAX_MODEL_CALLS=3
MODEL_CASCADE_LIGHT=gemini-3.5-flash-lite,gemini-3.1-flash-lite
MODEL_CASCADE_STRONG=gemini-3.5-flash-lite,gemini-3.1-flash-lite
NEXT_TELEMETRY_DISABLED=1
NODE: SECRET set=true length=47 sha256=4fa5e8ea
NODES_ROOT=/opt/render/project/nodes
NODE_ENV=production
NODE_GYP_FORCE_PYTHON=node-gyp-python
NODE_MODULES_CACHE=true
NODE_ROOT=/opt/render/project/nodes/node-22.12.0
NODE_VERBOSE=false
NODE_VERSION=
NPM_CONFIG_CACHE=/opt/render/.cache
NPM_CONFIG_DEVDIR=/opt/render/.cache
NPM_CONFIG_LOGLEVEL=error
NPM_CONFIG_STORE_DIR=/opt/render/.cache
PGSSLMODE=require
PIPENV_CACHE_DIR=/opt/render/.cache
PIPENV_QUIET=true
PIPENV_VENV_IN_PROJECT=true
PIPENV_YES=true
PIP_CACHE_DIR=/opt/render/.cache
PLAYWRIGHT_BROWSERS_PATH=/opt/render/project/playwright-browsers
POETRY_CACHE_DIR=/opt/render/.cache/.python-poetry/cache
POETRY_HOME=/home/render/.python-poetry
POETRY_VERSIONS_DIR=/opt/render/project/poetry
PORT=10000
PROJECT_RATE_LIMIT_PER_MINUTE=300
PROJECT_RUNTIME_CHECK=true
PYTHON_VERSIONS_DIR=/opt/render/project/python
RATE_LIMIT_PER_HOUR=200
RED=[31m
RENDER=true
RENDER_CPU_COUNT=0.15
RENDER_DIR=render
RENDER_DISCOVERY_SERVICE=bf-3tqo-discovery
RENDER_DOCKER_LOCAL_CACHE=/opt/render/docker-cache
RENDER_ENV=node
RENDER_ENV_IS_DOCKER=false
RENDER_EXTERNAL_HOSTNAME=bf-3tqo.onrender.com
RENDER_EXTERNAL_URL=https://bf-3tqo.onrender.com
RENDER_GIT_BRANCH=main
RENDER_GIT_COMMIT: SECRET set=true length=40 sha256=ddebd557
RENDER_GIT_REPO_SLUG=ecooorg/bf
RENDER_INSTANCE_ID: SECRET set=true length=51 sha256=d4731cd6
RENDER_INTERNAL_HOSTNAME: SECRET set=true length=67 sha256=e7ec2791
RENDER_INTERNAL_IP=10.24.125.13
RENDER_NATIVE_ENV_PATH=https://s3.us-east-2.amazonaws.com/ohio-prod-env-artifacts.render.com
RENDER_NODE_INSTALLED=true
RENDER_NODE_VERSION=22.12.0
RENDER_NODE_VERSION_DETECTED=true
RENDER_PM_DIR=/opt/render/project/src
RENDER_PM_ROOT=/home/render
RENDER_PRE_RUN_COMMAND=source /home/render/node-env.sh
RENDER_PROJECT_DIR=project
RENDER_PROJECT_ROOT=/opt/render/project
RENDER_REPO_ROOT=/opt/render/project/src
RENDER_ROOT=/opt/render
RENDER_SERVICE_CONTEXT_ROOT=/opt/render/project/src
RENDER_SERVICE_ID=srv-dc2joprrjlhs73cuo3n0
RENDER_SERVICE_NAME=bf-3tqo
RENDER_SERVICE_NS=own-dbbjfi7avr4c73e32e90
RENDER_SERVICE_SLUG=bf-3tqo
RENDER_SERVICE_TYPE=web
RENDER_SRC_ROOT=/opt/render/project/src
RENDER_USE_BUILD_TOOL_CLEAN_START=true
RENDER_USE_BUILD_TOOL_NODE=true
RENDER_USE_SLIM_PYTHON_ARTIFACT=true
RENDER_WEB_CONCURRENCY=1
RESEND_API_KEY=[REDACTED_API_KEY] set=true length=36 sha256=9ae15702
RESEND_API_KEY_1: SECRET set=true length=36 sha256=aee77ef2
RESET=(B[m
SEARCH_CAROUSEL=connector,serper,gemini
SERPER_API_KEY=[REDACTED_API_KEY] set=true length=40 sha256=9d588c61
SERVICE_URL=https://bf-3tqo.onrender.com
SESSION_SECRET: SECRET set=true length=40 sha256=553e19bf
TELEGRAM_BOT_TOKEN: SECRET set=true length=46 sha256=48011089
TELEGRAM_CHAT_ID=825225025
TRUST_PROXY_HOPS=1
UNGROUNDED_FACT_GATE=true
USER_RUN_COMMAND=npm run start
UV_CACHE_DIR=/opt/render/.cache/.python-uv/cache
UV_NO_MANAGED_PYTHON=true
UV_PYTHON_DOWNLOADS=never
UV_SYSTEM_PYTHON=1
UV_VERSIONS_DIR=/opt/render/project/uv
VENV_ROOT=/opt/render/project/src/.venv
VIRTUAL_ENV=/opt/render/project/src/.venv
VIRTUAL_ENV_DISABLE_PROMPT=true
VITE_GOOGLE_CLIENT_ID: SECRET set=true length=72 sha256=e0ca27f2
WEATHER_CONNECTOR_ENABLED=true
WEB_CONCURRENCY=1
WEB_SEARCH_DEFAULT_COUNTRY=CH
WEB_SEARCH_FETCH_PAGES=true
WEB_SEARCH_MAX_PAGES=2
WEB_SEARCH_MAX_QUERIES=2
WEB_SEARCH_PLANNER=true
WEB_SEARCH_TIMEOUT_MS=15000
WORKER_POLL_MS=5000
XDG_CACHE_HOME=/opt/render/.cache
YELLOW=[33m
ENV_SET_BUT_UNUSED (names only; scanned 360 source files): BLACK, BLUE, BOLD, BUN_HOME, BUN_VERSIONS_DIR, CYAN, DEBIAN_FRONTEND, DEFAULT_BUN_VERSION, DEFAULT_NODE_VERSION, DEFAULT_POETRY_VERSION, DEFAULT_PYTHON_VERSION, DEFAULT_UV_VERSION, DIM, ENTER_STANDOUT, EXIT_STANDOUT, GATSBY_TELEMETRY_DISABLED, GREEN, IMMOFINDER_BASE_URL, IMMOFINDER_DRIVE_SHARE_EMAIL, IS_PULL_REQUEST, MAGENTA, NEXT_TELEMETRY_DISABLED, NODES_ROOT, NODE_GYP_FORCE_PYTHON, NODE_MODULES_CACHE, NODE_ROOT, NODE_VERBOSE, NODE_VERSION, NPM_CONFIG_CACHE, NPM_CONFIG_DEVDIR, NPM_CONFIG_LOGLEVEL, NPM_CONFIG_STORE_DIR, PIPENV_CACHE_DIR, PIPENV_QUIET, PIPENV_VENV_IN_PROJECT, PIPENV_YES, PIP_CACHE_DIR, POETRY_CACHE_DIR, POETRY_HOME, POETRY_VERSIONS_DIR, PYTHON_VERSIONS_DIR, RESET, USER_RUN_COMMAND, UV_CACHE_DIR, UV_NO_MANAGED_PYTHON, UV_PYTHON_DOWNLOADS, UV_SYSTEM_PYTHON, UV_VERSIONS_DIR, VENV_ROOT, VIRTUAL_ENV, VIRTUAL_ENV_DISABLE_PROMPT, WEB_CONCURRENCY, XDG_CACHE_HOME, YELLOW
SEARCH_DECISIONS (last 40; expect gate reason, planSource, place, country, sourceCountry, dictated, queries, hosts — never secrets):
NO_SEARCH_DECISION_RECORDS
SEARCH_PLANNER_TIMING (last 40):
NO_SEARCH_PLANNER_TIMING_RECORDS
CONVERSATION_RESPONSES_AND_RELIABILITY_METRICS (last 80; separates generation from HTTP completion; client rendering is not inferred):
NO_CONVERSATION_EVENTS_CAPTURED
WARNINGS_AND_ERRORS (conversation, last 40):
NONE
CONVERSATION_HTTP_REQUESTS (last 40):
NO_CONVERSATION_HTTP_REQUESTS_CAPTURED
CAPTURE POLICY: conversation history, model prompts and outputs are captured for this single-user test environment. Secrets appear only as set/length/fingerprint. Project Mode operations are not part of this log.
